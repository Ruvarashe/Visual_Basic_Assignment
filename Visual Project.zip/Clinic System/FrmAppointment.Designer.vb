﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAppointment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LabelTITLE = New System.Windows.Forms.Label()
        Me.Button = New System.Windows.Forms.Button()
        Me.TextTITLE = New System.Windows.Forms.TextBox()
        Me.LabelSURNAME = New System.Windows.Forms.Label()
        Me.TextSURNAME = New System.Windows.Forms.TextBox()
        Me.LabelNAME = New System.Windows.Forms.Label()
        Me.TextNAME = New System.Windows.Forms.TextBox()
        Me.LabelID = New System.Windows.Forms.Label()
        Me.TextID = New System.Windows.Forms.TextBox()
        Me.LabelPHONE = New System.Windows.Forms.Label()
        Me.TextPHONE = New System.Windows.Forms.TextBox()
        Me.LabelAPPOINTMENT_DATE = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.ButtonSUBMIT = New System.Windows.Forms.Button()
        Me.CheckBoxRememberMe = New System.Windows.Forms.CheckBox()
        Me.GroupBoxGENDER = New System.Windows.Forms.GroupBox()
        Me.RadioButtonFEMALE = New System.Windows.Forms.RadioButton()
        Me.RadioButtonMALE = New System.Windows.Forms.RadioButton()
        Me.ButtonHOME = New System.Windows.Forms.Button()
        Me.ButtonABOUTUS = New System.Windows.Forms.Button()
        Me.ComboBoxAGENT = New System.Windows.Forms.ComboBox()
        Me.LabelCITIZENSHIP = New System.Windows.Forms.Label()
        Me.TextCITIZENSHIP = New System.Windows.Forms.TextBox()
        Me.LabelEMAL = New System.Windows.Forms.Label()
        Me.TextEMAIL = New System.Windows.Forms.TextBox()
        Me.LabelDOB = New System.Windows.Forms.Label()
        Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
        Me.GroupBoxGENDER.SuspendLayout()
        Me.SuspendLayout()
        '
        'LabelTITLE
        '
        Me.LabelTITLE.AutoSize = True
        Me.LabelTITLE.Location = New System.Drawing.Point(22, 97)
        Me.LabelTITLE.Name = "LabelTITLE"
        Me.LabelTITLE.Size = New System.Drawing.Size(37, 13)
        Me.LabelTITLE.TabIndex = 0
        Me.LabelTITLE.Text = "TITLE"
        '
        'Button
        '
        Me.Button.BackColor = System.Drawing.Color.Aqua
        Me.Button.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button.ForeColor = System.Drawing.Color.Red
        Me.Button.Location = New System.Drawing.Point(81, 21)
        Me.Button.Name = "Button"
        Me.Button.Size = New System.Drawing.Size(340, 49)
        Me.Button.TabIndex = 1
        Me.Button.Text = "FILL IN PATIENT DETAILS"
        Me.Button.UseVisualStyleBackColor = False
        '
        'TextTITLE
        '
        Me.TextTITLE.Location = New System.Drawing.Point(194, 90)
        Me.TextTITLE.Name = "TextTITLE"
        Me.TextTITLE.Size = New System.Drawing.Size(100, 20)
        Me.TextTITLE.TabIndex = 2
        '
        'LabelSURNAME
        '
        Me.LabelSURNAME.AutoSize = True
        Me.LabelSURNAME.Location = New System.Drawing.Point(22, 146)
        Me.LabelSURNAME.Name = "LabelSURNAME"
        Me.LabelSURNAME.Size = New System.Drawing.Size(61, 13)
        Me.LabelSURNAME.TabIndex = 3
        Me.LabelSURNAME.Text = "SURNAME"
        '
        'TextSURNAME
        '
        Me.TextSURNAME.Location = New System.Drawing.Point(196, 139)
        Me.TextSURNAME.Name = "TextSURNAME"
        Me.TextSURNAME.Size = New System.Drawing.Size(100, 20)
        Me.TextSURNAME.TabIndex = 4
        '
        'LabelNAME
        '
        Me.LabelNAME.AutoSize = True
        Me.LabelNAME.Location = New System.Drawing.Point(24, 194)
        Me.LabelNAME.Name = "LabelNAME"
        Me.LabelNAME.Size = New System.Drawing.Size(38, 13)
        Me.LabelNAME.TabIndex = 5
        Me.LabelNAME.Text = "NAME"
        '
        'TextNAME
        '
        Me.TextNAME.Location = New System.Drawing.Point(196, 187)
        Me.TextNAME.Name = "TextNAME"
        Me.TextNAME.Size = New System.Drawing.Size(100, 20)
        Me.TextNAME.TabIndex = 6
        '
        'LabelID
        '
        Me.LabelID.AutoSize = True
        Me.LabelID.Location = New System.Drawing.Point(41, 402)
        Me.LabelID.Name = "LabelID"
        Me.LabelID.Size = New System.Drawing.Size(18, 13)
        Me.LabelID.TabIndex = 7
        Me.LabelID.Text = "ID"
        '
        'TextID
        '
        Me.TextID.Location = New System.Drawing.Point(196, 395)
        Me.TextID.Name = "TextID"
        Me.TextID.Size = New System.Drawing.Size(100, 20)
        Me.TextID.TabIndex = 8
        '
        'LabelPHONE
        '
        Me.LabelPHONE.AutoSize = True
        Me.LabelPHONE.Location = New System.Drawing.Point(23, 514)
        Me.LabelPHONE.Name = "LabelPHONE"
        Me.LabelPHONE.Size = New System.Drawing.Size(45, 13)
        Me.LabelPHONE.TabIndex = 9
        Me.LabelPHONE.Text = "PHONE"
        '
        'TextPHONE
        '
        Me.TextPHONE.Location = New System.Drawing.Point(196, 514)
        Me.TextPHONE.Name = "TextPHONE"
        Me.TextPHONE.Size = New System.Drawing.Size(100, 20)
        Me.TextPHONE.TabIndex = 10
        '
        'LabelAPPOINTMENT_DATE
        '
        Me.LabelAPPOINTMENT_DATE.AutoSize = True
        Me.LabelAPPOINTMENT_DATE.Location = New System.Drawing.Point(23, 585)
        Me.LabelAPPOINTMENT_DATE.Name = "LabelAPPOINTMENT_DATE"
        Me.LabelAPPOINTMENT_DATE.Size = New System.Drawing.Size(117, 13)
        Me.LabelAPPOINTMENT_DATE.TabIndex = 16
        Me.LabelAPPOINTMENT_DATE.Text = "APPOINTMENT DATE"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(196, 585)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 17
        '
        'ButtonSUBMIT
        '
        Me.ButtonSUBMIT.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ButtonSUBMIT.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ButtonSUBMIT.Location = New System.Drawing.Point(354, 687)
        Me.ButtonSUBMIT.Name = "ButtonSUBMIT"
        Me.ButtonSUBMIT.Size = New System.Drawing.Size(81, 34)
        Me.ButtonSUBMIT.TabIndex = 18
        Me.ButtonSUBMIT.Text = "SUBMIT"
        Me.ButtonSUBMIT.UseVisualStyleBackColor = False
        '
        'CheckBoxRememberMe
        '
        Me.CheckBoxRememberMe.AutoSize = True
        Me.CheckBoxRememberMe.ForeColor = System.Drawing.Color.Blue
        Me.CheckBoxRememberMe.Location = New System.Drawing.Point(196, 656)
        Me.CheckBoxRememberMe.Name = "CheckBoxRememberMe"
        Me.CheckBoxRememberMe.Size = New System.Drawing.Size(98, 17)
        Me.CheckBoxRememberMe.TabIndex = 19
        Me.CheckBoxRememberMe.Text = " Remember Me"
        Me.CheckBoxRememberMe.UseVisualStyleBackColor = True
        '
        'GroupBoxGENDER
        '
        Me.GroupBoxGENDER.Controls.Add(Me.RadioButtonFEMALE)
        Me.GroupBoxGENDER.Controls.Add(Me.RadioButtonMALE)
        Me.GroupBoxGENDER.Location = New System.Drawing.Point(196, 296)
        Me.GroupBoxGENDER.Name = "GroupBoxGENDER"
        Me.GroupBoxGENDER.Size = New System.Drawing.Size(115, 78)
        Me.GroupBoxGENDER.TabIndex = 20
        Me.GroupBoxGENDER.TabStop = False
        Me.GroupBoxGENDER.Text = "GENDER"
        '
        'RadioButtonFEMALE
        '
        Me.RadioButtonFEMALE.AutoSize = True
        Me.RadioButtonFEMALE.Location = New System.Drawing.Point(7, 43)
        Me.RadioButtonFEMALE.Name = "RadioButtonFEMALE"
        Me.RadioButtonFEMALE.Size = New System.Drawing.Size(67, 17)
        Me.RadioButtonFEMALE.TabIndex = 1
        Me.RadioButtonFEMALE.TabStop = True
        Me.RadioButtonFEMALE.Text = "FEMALE"
        Me.RadioButtonFEMALE.UseVisualStyleBackColor = True
        '
        'RadioButtonMALE
        '
        Me.RadioButtonMALE.AutoSize = True
        Me.RadioButtonMALE.Location = New System.Drawing.Point(7, 20)
        Me.RadioButtonMALE.Name = "RadioButtonMALE"
        Me.RadioButtonMALE.Size = New System.Drawing.Size(54, 17)
        Me.RadioButtonMALE.TabIndex = 0
        Me.RadioButtonMALE.TabStop = True
        Me.RadioButtonMALE.Text = "MALE"
        Me.RadioButtonMALE.UseVisualStyleBackColor = True
        '
        'ButtonHOME
        '
        Me.ButtonHOME.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ButtonHOME.Font = New System.Drawing.Font("Curlz MT", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonHOME.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ButtonHOME.Location = New System.Drawing.Point(26, 656)
        Me.ButtonHOME.Name = "ButtonHOME"
        Me.ButtonHOME.Size = New System.Drawing.Size(58, 23)
        Me.ButtonHOME.TabIndex = 21
        Me.ButtonHOME.Text = "HOME"
        Me.ButtonHOME.UseVisualStyleBackColor = False
        '
        'ButtonABOUTUS
        '
        Me.ButtonABOUTUS.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ButtonABOUTUS.Font = New System.Drawing.Font("Buxton Sketch", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonABOUTUS.ForeColor = System.Drawing.Color.Blue
        Me.ButtonABOUTUS.Location = New System.Drawing.Point(25, 698)
        Me.ButtonABOUTUS.Name = "ButtonABOUTUS"
        Me.ButtonABOUTUS.Size = New System.Drawing.Size(75, 23)
        Me.ButtonABOUTUS.TabIndex = 22
        Me.ButtonABOUTUS.Text = "ABOUT US"
        Me.ButtonABOUTUS.UseVisualStyleBackColor = False
        '
        'ComboBoxAGENT
        '
        Me.ComboBoxAGENT.FormattingEnabled = True
        Me.ComboBoxAGENT.Items.AddRange(New Object() {"UNESCO", "UNFAO", "WHO", "UNIMP", "UNIDO", "UNWTO"})
        Me.ComboBoxAGENT.Location = New System.Drawing.Point(25, 324)
        Me.ComboBoxAGENT.Name = "ComboBoxAGENT"
        Me.ComboBoxAGENT.Size = New System.Drawing.Size(121, 21)
        Me.ComboBoxAGENT.TabIndex = 23
        Me.ComboBoxAGENT.Text = "AGENT"
        '
        'LabelCITIZENSHIP
        '
        Me.LabelCITIZENSHIP.AutoSize = True
        Me.LabelCITIZENSHIP.Location = New System.Drawing.Point(22, 463)
        Me.LabelCITIZENSHIP.Name = "LabelCITIZENSHIP"
        Me.LabelCITIZENSHIP.Size = New System.Drawing.Size(74, 13)
        Me.LabelCITIZENSHIP.TabIndex = 24
        Me.LabelCITIZENSHIP.Text = "CITIZENSHIP"
        '
        'TextCITIZENSHIP
        '
        Me.TextCITIZENSHIP.Location = New System.Drawing.Point(196, 456)
        Me.TextCITIZENSHIP.Name = "TextCITIZENSHIP"
        Me.TextCITIZENSHIP.Size = New System.Drawing.Size(100, 20)
        Me.TextCITIZENSHIP.TabIndex = 25
        '
        'LabelEMAL
        '
        Me.LabelEMAL.AutoSize = True
        Me.LabelEMAL.Location = New System.Drawing.Point(23, 277)
        Me.LabelEMAL.Name = "LabelEMAL"
        Me.LabelEMAL.Size = New System.Drawing.Size(39, 13)
        Me.LabelEMAL.TabIndex = 26
        Me.LabelEMAL.Text = "EMAIL"
        '
        'TextEMAIL
        '
        Me.TextEMAIL.Location = New System.Drawing.Point(196, 270)
        Me.TextEMAIL.Name = "TextEMAIL"
        Me.TextEMAIL.Size = New System.Drawing.Size(100, 20)
        Me.TextEMAIL.TabIndex = 27
        '
        'LabelDOB
        '
        Me.LabelDOB.AutoSize = True
        Me.LabelDOB.Location = New System.Drawing.Point(23, 239)
        Me.LabelDOB.Name = "LabelDOB"
        Me.LabelDOB.Size = New System.Drawing.Size(30, 13)
        Me.LabelDOB.TabIndex = 28
        Me.LabelDOB.Text = "DOB"
        '
        'DateTimePicker2
        '
        Me.DateTimePicker2.Location = New System.Drawing.Point(194, 232)
        Me.DateTimePicker2.Name = "DateTimePicker2"
        Me.DateTimePicker2.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker2.TabIndex = 29
        '
        'FrmAppointment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightCyan
        Me.ClientSize = New System.Drawing.Size(562, 725)
        Me.Controls.Add(Me.DateTimePicker2)
        Me.Controls.Add(Me.LabelDOB)
        Me.Controls.Add(Me.TextEMAIL)
        Me.Controls.Add(Me.LabelEMAL)
        Me.Controls.Add(Me.TextCITIZENSHIP)
        Me.Controls.Add(Me.LabelCITIZENSHIP)
        Me.Controls.Add(Me.ComboBoxAGENT)
        Me.Controls.Add(Me.ButtonABOUTUS)
        Me.Controls.Add(Me.ButtonHOME)
        Me.Controls.Add(Me.GroupBoxGENDER)
        Me.Controls.Add(Me.CheckBoxRememberMe)
        Me.Controls.Add(Me.ButtonSUBMIT)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.LabelAPPOINTMENT_DATE)
        Me.Controls.Add(Me.TextPHONE)
        Me.Controls.Add(Me.LabelPHONE)
        Me.Controls.Add(Me.TextID)
        Me.Controls.Add(Me.LabelID)
        Me.Controls.Add(Me.TextNAME)
        Me.Controls.Add(Me.LabelNAME)
        Me.Controls.Add(Me.TextSURNAME)
        Me.Controls.Add(Me.LabelSURNAME)
        Me.Controls.Add(Me.TextTITLE)
        Me.Controls.Add(Me.Button)
        Me.Controls.Add(Me.LabelTITLE)
        Me.Name = "FrmAppointment"
        Me.Text = "Appointment Booking"
        Me.GroupBoxGENDER.ResumeLayout(False)
        Me.GroupBoxGENDER.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LabelTITLE As System.Windows.Forms.Label
    Friend WithEvents Button As System.Windows.Forms.Button
    Friend WithEvents TextTITLE As System.Windows.Forms.TextBox
    Friend WithEvents LabelSURNAME As System.Windows.Forms.Label
    Friend WithEvents TextSURNAME As System.Windows.Forms.TextBox
    Friend WithEvents LabelNAME As System.Windows.Forms.Label
    Friend WithEvents TextNAME As System.Windows.Forms.TextBox
    Friend WithEvents LabelID As System.Windows.Forms.Label
    Friend WithEvents TextID As System.Windows.Forms.TextBox
    Friend WithEvents LabelPHONE As System.Windows.Forms.Label
    Friend WithEvents TextPHONE As System.Windows.Forms.TextBox
    Friend WithEvents LabelAPPOINTMENT_DATE As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents ButtonSUBMIT As System.Windows.Forms.Button
    Friend WithEvents CheckBoxRememberMe As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBoxGENDER As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButtonFEMALE As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonMALE As System.Windows.Forms.RadioButton
    Friend WithEvents ButtonHOME As System.Windows.Forms.Button
    Friend WithEvents ButtonABOUTUS As System.Windows.Forms.Button
    Friend WithEvents ComboBoxAGENT As System.Windows.Forms.ComboBox
    Friend WithEvents LabelCITIZENSHIP As System.Windows.Forms.Label
    Friend WithEvents TextCITIZENSHIP As System.Windows.Forms.TextBox
    Friend WithEvents LabelEMAL As System.Windows.Forms.Label
    Friend WithEvents TextEMAIL As System.Windows.Forms.TextBox
    Friend WithEvents LabelDOB As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker2 As System.Windows.Forms.DateTimePicker
End Class
