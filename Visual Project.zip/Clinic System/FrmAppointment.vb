﻿Imports MySql.Data.MySqlClient
Public Class FrmAppointment
    Dim MysqlConn As MySqlConnection
    Dim COMMAND As MySqlCommand

    Private Sub TextAGENT_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub LabelAGENT_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ButtonSUBMIT_Click(sender As Object, e As EventArgs) Handles ButtonSUBMIT.Click
        


        If TextCITIZENSHIP.Text = "" Then
            MsgBox("Citizenship can not be empty")
            TextCITIZENSHIP.Focus()
        
        End If

        If TextEMAIL.Text = "" Then
            MsgBox("Email can not be empty")
            TextEMAIL.Focus()


        End If

        If TextPHONE.Text = "" Then
            MsgBox("Phone can not be empty")
            TextPHONE.Focus()


        End If

        If TextNAME.Text = "" Then
            MsgBox("Name can not be empty")
            TextNAME.Focus()


        End If

        If TextSURNAME.Text = "" Then
            MsgBox("Surname can not be empty")
            TextSURNAME.Focus()
      
        End If

        If TextTITLE.Text = "" Then
            MsgBox("Title can not be empty")
            TextTITLE.Focus()
       
        End If

        If ComboBoxAGENT.Text = "" Then
            MsgBox("Agent can not be empty")
            ComboBoxAGENT.Focus()


        End If

        If GroupBoxGENDER.Text = "" Then
            MsgBox("Gender can not be empty")
            GroupBoxGENDER.Focus()
       
        End If

        If DateTimePicker1.Text = "" Then
            MsgBox("Date can not be empty")
            DateTimePicker1.Focus()
       
        End If


        If DateTimePicker2.Text = "" Then
            MsgBox("Agent can not be empty")
            DateTimePicker2.Focus()
       
        End If

        If TextID.Text = "" Then
            MsgBox("ID can not be empty")
            TextID.Focus()
       
        End If

        SavePatient()



      
        
    End Sub
    Private Sub FrmRegister_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim CommandObject As MySqlCommand
        Dim sqlString As String
        Dim DataReader As MySqlDataReader
        sqlString = "Select name FROM Levels"
        CommandObject = New MySqlCommand(sqlString, ClinicConnection())
        DataReader = CommandObject.ExecuteReader
        While (DataReader.Read())
            ' cboLevel.Items.Add(DataReader.GetString("name"))
        End While
    End Sub
End Class