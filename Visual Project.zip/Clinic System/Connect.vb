﻿Imports MySql.Data.MySqlClient
Module Connect
    Public Sub connect()
        Dim connObject As New MySqlConnection
        Dim connString As String
        connString = "server=localhost;userid=root;password=;database=clinicsystem_db"
        connObject.ConnectionString = connString

        Try
            connObject.Open()
            MsgBox("Connection Successfull")

          
        Catch ex As MySqlException
            MsgBox(ex.Message)
        Finally
            connObject.Dispose()


        End Try
    End Sub
End Module
