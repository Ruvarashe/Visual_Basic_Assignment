﻿Imports System.Convert
Imports MySql.Data.MySqlClient
Module valid
    Sub Connection()
        Dim connectionString As String
        Dim connObject As New MySqlConnection
        connectionString = "server=localhost;userid=root;database=clinicsystem_db"
        connObject.ConnectionString = connectionString
        Try
            connObject.Open()

        Catch ex As MySqlException
            MsgBox(ex.Message)

        End Try

    End Sub
    Function ClinicConnection() As MySqlConnection
        Dim connectionString As String
        Dim connObject As New MySqlConnection
        connectionString = "server=localhost;userid=root;database=clinicsystem_db"
        connObject.ConnectionString = connectionString
        Try
            connObject.Open()
            MsgBox("connected")
        Catch ex As MySqlException
            MsgBox(ex.Message)

        End Try
        Return connObject
    End Function
    Sub SavePatient()

        Dim Title As String
        Dim Surname As String
        Dim Name As String
        Dim ID As String
        Dim DOB As Date
        Dim Agent As String
        Dim Phone As Integer
        Dim Email As String
        Dim Gender As String
        Dim Citizenship As String
        Dim Appointment_Date As Date

        Dim cmd As New MySqlCommand
        Dim sqlString As String
        With FrmAppointment

            Citizenship = .TextCITIZENSHIP.Text
            Surname = .TextSURNAME.Text
            Title = .TextTITLE.Text
            Gender = .GroupBoxGENDER.Text
            Appointment_Date = .DateTimePicker1.Text
            DOB = .DateTimePicker2.Text
            ID = .TextID.Text
            Email = .TextEMAIL.Text
            Name = .TextNAME.Text
            Phone = .TextPHONE.Text
            Agent = .ComboBoxAGENT.Text



        End With
        sqlString = "INSERT INTO appointmenttable VALUES('" & ID & "','" & _
            Title & "','" & Surname & "'," & Name & "," & Gender & ",'" & _
        Citizenship & "','" & Agent & "','" & DOB & "','" & Phone & "','" & Email & "','" & Appointment_Date & "')"

        With cmd
            .Connection = ClinicConnection()
            .CommandText = sqlString
            .CommandType = CommandType.Text
            .ExecuteNonQuery()
        End With
        MsgBox("Patient Saved")

    End Sub

End Module

