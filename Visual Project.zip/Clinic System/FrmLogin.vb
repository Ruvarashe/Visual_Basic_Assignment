﻿Public Class FrmLogin

    Private Sub ButtonSubmit_Click(sender As Object, e As EventArgs) Handles ButtonSubmit.Click
        If TextUsername.Text = "UNDPCLINIC" And TextPassword.Text = "UNDP12" Then
            MsgBox("login successful")
            FrmAppointment.Show()
            Me.Hide()
        Else
            MsgBox("wrong password or username")

        End If
    End Sub

    Private Sub TextPassword_TextChanged(sender As Object, e As EventArgs) Handles TextPassword.TextChanged

    End Sub

    Private Sub LabelPassword_Click(sender As Object, e As EventArgs) Handles LabelPassword.Click

    End Sub

    Private Sub ButtonUNDP_Click(sender As Object, e As EventArgs) Handles ButtonUNDP.Click

    End Sub
End Class
